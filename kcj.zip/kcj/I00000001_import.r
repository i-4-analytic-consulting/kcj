

library(readr)

# where is my wd
getwd()
# set wd if needed
setwd(file.choose())

# import .csv
I00000001 <- read_csv("I00000001.csv")

# view dataframe
View(I00000001) 